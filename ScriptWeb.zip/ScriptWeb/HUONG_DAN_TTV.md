# Bản 1.2 – ghi chú

Menu (bảng tiện ích) và script TungTomVND giữ NGUYÊN, không sửa.

## Chống nóng máy (tự động, không cần bật tắt)
Dùng bộ giảm đồ họa của PokeSurvivorTool-Lite (assets/ttv_engine.js, MIT):
- Mát (< 38°C): "Nhẹ"  = giảm độ phân giải ≤1x, bỏ bóng/glow, tắt hiệu ứng CSS
- Ấm (38–42°C): "Vừa" = thêm bỏ số sát thương/bụi, vẽ 1/2 số khung hình
- Nóng (≥ 42°C) hoặc đang ngủ: "Tối đa" = độ phân giải 0.5x, vẽ 1/3 số khung hình, bỏ nền đất
Logic game/bot vẫn chạy đủ tốc độ, chỉ phần VẼ bị giảm. Có độ trễ 2°C để không đổi mức liên tục.

## Chế độ ngủ
Giữ nút logo ~0,7 giây. Chạm 2 lần (hoặc Back) để thoát.
Số liệu đọc từ bảng #psbot của script: Pokémon (Build tối ưu · Tên), Lv, số ván, hạ gục,
vàng kiếm (dòng "Lần treo máy này…"), Pokémon vừa quay (Đã quay), hoạt động hiện tại.
Thời gian treo bám theo đồng hồ phút của chính script.
