// TungTomVND engine.
// Phần 1: bộ giảm đồ hoạ lấy từ PokeSurvivorTool-Lite core/lite.js (MIT, (c) 2026 damhieu2808),
//         chỉ sửa 1 chỗ: CSS giảm hiệu ứng KHÔNG áp lên bảng điều khiển #psbot của script.
// Phần 2: cầu nối gửi số liệu từ bảng #psbot của script về màn hình ngủ của app.
// PokeSurvivor Lite: giảm đồ hoạ / tăng FPS cho pokesurvivor.com và pokesurvivor.doofcraft.com.
// Runs at document_start in the page's own world, before the game creates its canvas (needed for the resolution scale).
// Rule: the bot (core/bot.js) records every draw call BEFORE it reaches the wrappers below, so everything here only
// decides what reaches the screen. The bot keeps seeing every sprite / telegraph, whatever is dropped.
// Settings live in localStorage ('psbot.lite'); the panel's "Cài đặt" tab drives them through window.PSLite.
(() => {
  if (window.PSLite) return;
  const KEY = 'psbot.lite';
  // dpr:    0 = leave the browser's devicePixelRatio alone, else the cap (never above the native one)
  // shadow: force canvas shadowBlur / shadowColor / filter off (blur is the costliest 2D canvas feature)
  // glow:   drop radial-gradient glows and everything drawn with additive blending ('lighter')
  // part:   drop floating damage numbers and faint dust-sized squares
  // css:    near-instant CSS animations / transitions, no backdrop blur / filters / shadows on the game's own DOM
  // pixel:  no image smoothing (pixel art: nearest-neighbour is cheaper) + pixelated upscaling of the canvas
  // skip:   draw only every Nth frame; the game's logic keeps its full rate, so the game does not slow down
  // fps:    0 = off, else max frames per second given to the game's requestAnimationFrame callbacks (slows the game)
  // hide:   0 = off, 1 = hide enemies far from the player, 2 = hide every enemy (bot.js does it, it knows the sprites)
  // bg:     do not paint the map's 256x256 ground chunks (the bot still reads them for walls / liquid)
  const DEF = { dpr: 0, shadow: false, glow: false, part: false, css: false, pixel: false, skip: 1, fps: 0, hide: 0, bg: false };
  const PRESETS = {
    off: { ...DEF },
    light: { ...DEF, dpr: 1, shadow: true, glow: true, css: true, pixel: true },
    strong: { ...DEF, dpr: 0.75, shadow: true, glow: true, part: true, css: true, pixel: true, skip: 2, hide: 1 },
    max: { ...DEF, dpr: 0.5, shadow: true, glow: true, part: true, css: true, pixel: true, skip: 3, hide: 2, bg: true },
  };
  const cfg = { ...DEF };
  try {
    const saved = JSON.parse(localStorage.getItem(KEY) || '{}');
    for (const k in DEF) if (k in saved && typeof saved[k] === typeof DEF[k]) cfg[k] = saved[k];
  } catch {}
  const save = () => { try { localStorage.setItem(KEY, JSON.stringify(cfg)); } catch {} };

  // ---- 1) resolution: the game sizes its canvas as CSS size × devicePixelRatio, so a lower ratio = far fewer pixels ----
  const dprDesc = Object.getOwnPropertyDescriptor(window, 'devicePixelRatio');
  const nativeDpr = () => { try { return (dprDesc && dprDesc.get ? dprDesc.get.call(window) : dprDesc && dprDesc.value) || 1; } catch { return 1; } };
  try {
    Object.defineProperty(window, 'devicePixelRatio', {
      configurable: true,
      enumerable: true,
      get: () => (cfg.dpr > 0 ? Math.min(cfg.dpr, nativeDpr()) : nativeDpr()),
    });
  } catch {}

  // ---- 2) canvas state forced while a setting is on (shadows, filters, smoothing) ----
  const P = window.CanvasRenderingContext2D && CanvasRenderingContext2D.prototype;
  const force = (name, value, on) => {
    const d = P && Object.getOwnPropertyDescriptor(P, name);
    if (!d || !d.set || !d.configurable) return;
    Object.defineProperty(P, name, { ...d, set(v) { d.set.call(this, on() ? value : v); } });
  };
  force('shadowBlur', 0, () => cfg.shadow);
  force('shadowColor', 'rgba(0,0,0,0)', () => cfg.shadow);
  force('filter', 'none', () => cfg.shadow);
  force('imageSmoothingEnabled', false, () => cfg.pixel);
  force('imageSmoothingQuality', 'low', () => cfg.pixel);

  // ---- 3) draw filter: what reaches the visible game canvas ----
  // Only the big canvas that sits in the page counts; the offscreen canvases the game builds its sprites on are never touched
  let main = null;
  const isMain = ctx => {
    const c = ctx.canvas;
    if (c === main) return true;
    if (c && c.isConnected && c.width >= 320 && c.height >= 240) { main = c; return true; }
    return false;
  };
  let open = true;                                      // false while a frame is being skipped (set once per vsync below)
  const radial = new WeakSet();                         // radial gradients = glows (linear ones are backgrounds: kept)
  if (P && P.createRadialGradient) {
    const o = P.createRadialGradient;
    P.createRadialGradient = function () { const g = o.apply(this, arguments); radial.add(g); return g; };
  }
  const NUM = /^[+\-]?\d[\d.,]{0,5}[kKmM]?!?$/;         // "12", "-340", "1.2k": a damage / heal popup
  const tiny = (ctx, w, h) => { const s = Math.abs(ctx.getTransform().a) || 1; return Math.abs(w * h) * s * s < 64; };
  // The game does not clear its canvas every frame: the ground wipes the previous frame as it is drawn over it. So a
  // ground chunk is not just skipped, a flat colour takes its place (a skipped one would leave trails of every effect)
  const rawFillRect = P && P.fillRect;
  const flat = (ctx, a) => {
    const n = a.length, w = n >= 9 ? a[7] : n >= 5 ? a[3] : a[0].width, h = n >= 9 ? a[8] : n >= 5 ? a[4] : a[0].height;
    const x = n >= 9 ? a[5] : a[1], y = n >= 9 ? a[6] : a[2];
    const fs = ctx.fillStyle, ga = ctx.globalAlpha, go = ctx.globalCompositeOperation;
    ctx.fillStyle = '#16221b'; ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over';
    rawFillRect.call(ctx, x - 1, y - 1, w + 2, h + 2);          // 1 px more each side: no seams between chunks
    ctx.fillStyle = fs; ctx.globalAlpha = ga; ctx.globalCompositeOperation = go;
    return true;
  };
  const drop = (ctx, name, a) => {
    if (!isMain(ctx)) return false;
    if (!open) return true;                             // skipped frame: the previous one simply stays on screen
    if (cfg.glow && (ctx.globalCompositeOperation === 'lighter' || (name !== 'drawImage' && radial.has(ctx.fillStyle)))) return true;
    if (cfg.part) {
      if (name === 'fillText' || name === 'strokeText') { if (NUM.test(String(a[0]).trim())) { const m = ctx.getTransform(); if (m.e !== 0 || m.f !== 0) return true; } }
      else if (name === 'fillRect' && ctx.globalAlpha < 0.9 && tiny(ctx, a[2], a[3])) return true;
    }
    if (cfg.bg && name === 'drawImage') { const i = a[0]; if (i && i.width === 256 && i.height === 256 && i.getContext) return flat(ctx, a); }
    return false;
  };
  // True while any of the settings needs the wrappers to look at a call (keeps the default path nearly free)
  const active = () => !open || cfg.glow || cfg.part || cfg.bg;
  if (P) ['drawImage', 'fillRect', 'clearRect', 'strokeRect', 'fill', 'stroke', 'fillText', 'strokeText'].forEach(name => {
    const o = P[name];
    if (typeof o !== 'function') return;
    P[name] = function () { return active() && drop(this, name, arguments) ? undefined : o.apply(this, arguments); };
  });

  // ---- 4) frames: callbacks of one browser frame share one timestamp, so all of them run together or all wait ----
  const nativeRAF = window.requestAnimationFrame, nativeCAF = window.cancelAnimationFrame;
  const later = new Map();                              // our id -> the native id currently holding the request
  let seq = 1e9, allowedT = -1, lastT = -1e9, frameT = -1, frameNo = 0;
  const mark = t => { if (t !== frameT) { frameT = t; frameNo++; open = cfg.skip <= 1 || frameNo % cfg.skip === 0; } };
  window.requestAnimationFrame = function (cb) {
    if (!cfg.fps) return nativeRAF.call(window, cfg.skip > 1 ? t => { mark(t); return cb(t); } : cb);
    const id = ++seq;
    const gap = 1000 / cfg.fps - 3;                     // a little slack: 30 on a 60 Hz screen lands on every 2nd vsync
    const step = t => {
      if (t === allowedT || t - lastT >= gap) { allowedT = t; lastT = t; later.delete(id); mark(t); return cb(t); }
      later.set(id, nativeRAF.call(window, step));
    };
    later.set(id, nativeRAF.call(window, step));
    return id;
  };
  window.cancelAnimationFrame = function (id) {
    if (later.has(id)) { nativeCAF.call(window, later.get(id)); later.delete(id); } else nativeCAF.call(window, id);
  };

  // ---- 5) CSS on the game's own DOM (the bot's panels carry data-psbot-ui and are left alone) ----
  // Durations stay > 0 so animationend / transitionend still fire for anything the game waits on
  const CSS = `
    body *:not([data-psbot-ui]):not([data-psbot-ui] *):not(#psbot):not(#psbot *) {
      animation-duration: .001s !important; animation-delay: 0s !important; animation-iteration-count: 1 !important;
      transition-duration: .001s !important; transition-delay: 0s !important;
      backdrop-filter: none !important; -webkit-backdrop-filter: none !important; filter: none !important;
      text-shadow: none !important; box-shadow: none !important; mix-blend-mode: normal !important; will-change: auto !important;
    }`;
  const PIXEL_CSS = 'canvas:not([data-psbot-ui]) { image-rendering: pixelated !important; image-rendering: crisp-edges !important; }';
  const styles = {};
  const toggleStyle = (id, on, text) => {
    if (on && !styles[id]) {
      // Very early on there may be no <html> yet: try again once the document is parsed
      if (!document.head && !document.documentElement) return void document.addEventListener('DOMContentLoaded', applyCss, { once: true });
      const s = document.createElement('style');
      s.id = id; s.textContent = text;
      (document.head || document.documentElement).append(s);
      styles[id] = s;
    } else if (!on && styles[id]) { styles[id].remove(); delete styles[id]; }
  };
  const applyCss = () => { toggleStyle('psbot-lite-css', cfg.css, CSS); toggleStyle('psbot-lite-px', cfg.pixel, PIXEL_CSS); };

  const same = (a, b) => Object.keys(DEF).every(k => a[k] === b[k]);
  window.PSLite = {
    live: cfg,                                          // the live settings object: bot.js reads it on every draw, no copy
    get: () => ({ ...cfg }),
    native: nativeDpr,
    presets: PRESETS,
    matchPreset: () => Object.keys(PRESETS).find(n => same(cfg, PRESETS[n])) || '',
    set(patch) {
      const dprChanged = 'dpr' in patch && patch.dpr !== cfg.dpr;
      for (const k in patch) if (k in DEF && typeof patch[k] === typeof DEF[k]) cfg[k] = patch[k];
      if (cfg.skip <= 1) open = true;
      save();
      applyCss();
      // Most games re-measure their canvas on resize: this applies the new ratio without a reload
      if (dprChanged) try { window.dispatchEvent(new Event('resize')); } catch {}
    },
    preset(name) { if (PRESETS[name]) this.set({ ...PRESETS[name] }); },
  };
  applyCss();
})();

// ======================= Phần 2: cầu nối với app =======================
(function () {
  'use strict';
  if (window.__ttvInit) return;
  window.__ttvInit = true;

  var cfg = window.__ttvCfg || {};
  var scanMs = cfg.scanMs || 8000;

  function hasBridge() {
    return typeof window.TTV === 'object' && window.TTV && typeof window.TTV.postMessage === 'function';
  }
  function sendRaw(s) { try { if (hasBridge()) window.TTV.postMessage(s); } catch (e) {} }
  function send(o) { try { sendRaw(JSON.stringify(o)); } catch (e) {} }

  // Mức giảm đồ hoạ do app chọn theo nhiệt độ / chế độ ngủ: light | strong | max
  function applyPreset(name) {
    try {
      var L = window.PSLite;
      if (L && L.presets && L.presets[name] && L.matchPreset() !== name) L.preset(name);
    } catch (e) {}
  }
  if (cfg.preset) applyPreset(cfg.preset);

  if (hasBridge()) {
    window.TTV.onmessage = function (ev) {
      try {
        var c = JSON.parse(ev.data);
        if (typeof c.preset === 'string') applyPreset(c.preset);
        if (typeof c.scanMs === 'number') scanMs = c.scanMs;
      } catch (e) {}
    };
    send({ hello: 1 });
  }

  // API tuỳ chọn cho script khác: TTV_REPORT({pokemon, level, earned, runs, kills, task, farmed})
  var pend = null, timer = 0, lastSent = '';
  function flush() {
    timer = 0;
    if (!pend) return;
    var s;
    try { s = JSON.stringify(pend); } catch (e) { pend = null; return; }
    pend = null;
    if (s !== lastSent) { lastSent = s; sendRaw(s); }
  }
  window.TTV_REPORT = function (o) {
    if (!o || typeof o !== 'object') return;
    pend = Object.assign(pend || {}, o);
    if (!timer) timer = setTimeout(flush, 500);
  };

  // Đọc bảng điều khiển #psbot của script TungTomVND (chỉ đọc chữ, không đụng gì vào bảng)
  function scanPanel() {
    var p = document.getElementById('psbot');
    if (!p) return null;
    var out = {}, any = false, m;
    var pt = p.querySelector('[data-k="ptitle"]');
    if (pt) {
      m = /·\s*(.+?)(?:\s*\(chế độ tự động\))?\s*$/.exec((pt.textContent || '').trim());
      if (m && m[1]) { out.pokemon = m[1].trim(); any = true; }
    }
    var st = p.querySelector('[data-k="status"]');
    if (st) {
      var kids = st.children;
      for (var i = 0; i < kids.length; i++) {
        var t = (kids[i].textContent || '').trim();
        if ((m = /^Lv(\d+)\b/.exec(t))) {
          out.level = +m[1];
          var parts = t.split(' · ');
          out.task = (parts[parts.length - 1] || '').trim();
          any = true;
        } else if ((m = /^Lần treo máy này (\d+) phút:\s*(\d+) ván,\s*Hạ gục (\d+),\s*Vàng (\d+)/.exec(t))) {
          out.mins = +m[1]; out.runs = +m[2]; out.kills = +m[3]; out.earned = +m[4];
          any = true;
        } else if ((m = /^Đã quay:\s*(.+)$/.exec(t))) { out.gacha = m[1]; any = true; }
        else if ((m = /^Nâng cấp:\s*(.+)$/.exec(t))) { out.upgrade = m[1]; any = true; }
      }
    }
    return any ? out : null;
  }

  var lastScan = '';
  function cycle() {
    try {
      var st = window.TTV_STATE;
      if (st && typeof st === 'object') window.TTV_REPORT(st);
      var r = scanPanel();
      if (r) {
        var s = JSON.stringify(r);
        if (s !== lastScan) { lastScan = s; sendRaw(s); }
      }
    } catch (e) {}
    setTimeout(cycle, scanMs);
  }
  setTimeout(cycle, 2500);
})();
