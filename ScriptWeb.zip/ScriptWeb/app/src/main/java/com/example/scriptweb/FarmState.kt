package com.example.scriptweb

import android.os.SystemClock
import org.json.JSONObject
import java.text.NumberFormat
import java.util.Locale

/**
 * Số liệu phiên treo. App KHÔNG tự tính gì: engine chỉ đọc chữ trên bảng #psbot của script rồi báo về đây,
 * màn hình ngủ chỉ hiển thị lại. Sống theo process nên xoay màn hình không bị mất.
 */
object FarmState {
    var pokemon: String? = null; private set
    var level: Int? = null; private set
    var earned: Long? = null; private set      // vàng đã kiếm (script báo thẳng)
    var gold: Long? = null; private set        // vàng đang có (chỉ khi script khác báo)
    var runs: Int? = null; private set
    var kills: Int? = null; private set
    var task: String? = null; private set
    var gacha: String? = null; private set
    var upgrade: String? = null; private set
    var farmed: String? = null; private set    // chữ tự do (API TTV_REPORT)

    var startedAt: Long = SystemClock.elapsedRealtime(); private set
    private var derived = 0L                   // vàng kiếm tính từ chênh lệch `gold`, khi không có `earned`
    private var lastGold: Long? = null

    val hasData get() = pokemon != null || level != null || earned != null || gold != null || runs != null || farmed != null

    private val nf = NumberFormat.getInstance(Locale("vi", "VN"))
    fun fmt(n: Long): String = nf.format(n)

    fun uptimeText(): String {
        val s = (SystemClock.elapsedRealtime() - startedAt) / 1000
        val d = s / 86400; val h = (s % 86400) / 3600; val m = (s % 3600) / 60; val sec = s % 60
        val hms = "%02d:%02d:%02d".format(h, m, sec)
        return if (d > 0) "$d ngày $hms" else hms
    }

    /** "Treo được những gì": số ván, hạ gục, và Pokémon vừa quay được. */
    fun farmedText(): String {
        val lines = mutableListOf<String>()
        farmed?.let { lines += it }
        if (runs != null || kills != null)
            lines += listOfNotNull(runs?.let { "${fmt(it.toLong())} ván" }, kills?.let { "${fmt(it.toLong())} hạ gục" }).joinToString(" · ")
        gacha?.let { lines += "Đã quay: $it" }
        return if (lines.isEmpty()) "—" else lines.joinToString("\n")
    }

    fun goldText(): String {
        earned?.let { return "+${fmt(it)}" }
        val g = gold ?: return "—"
        return "+${fmt(derived)}   ·   hiện có ${fmt(g)}"
    }

    fun ingest(raw: String) {
        val o = try { JSONObject(raw) } catch (_: Exception) { return }

        (o.opt("pokemon") as? String)?.trim()?.takeIf { it.isNotEmpty() }?.let { pokemon = it.take(40) }
        (o.opt("level") ?: o.opt("lv"))?.let { toNum(it) }?.takeIf { it in 1..9999 }?.let { level = it.toInt() }
        o.opt("earned")?.let { toNum(it) }?.takeIf { it >= 0 }?.let { earned = it }
        o.opt("gold")?.let { toNum(it) }?.takeIf { it > 0 }?.let { gold = it }
        o.opt("runs")?.let { toNum(it) }?.takeIf { it >= 0 }?.let { runs = it.toInt() }
        o.opt("kills")?.let { toNum(it) }?.takeIf { it >= 0 }?.let { kills = it.toInt() }
        (o.opt("task") as? String)?.let { task = it.trim().take(60).ifEmpty { null } }
        (o.opt("gacha") as? String)?.let { gacha = it.trim().take(120).ifEmpty { null } }
        (o.opt("upgrade") as? String)?.let { upgrade = it.trim().take(120).ifEmpty { null } }
        (o.opt("farmed") as? String)?.let { farmed = it.trim().take(200).ifEmpty { null } }

        // Script có đồng hồ phiên riêng (phút): bám theo nó để thời gian treo và số vàng luôn cùng một phiên
        o.opt("mins")?.let { toNum(it) }?.takeIf { it >= 0 }?.let { mins ->
            val now = SystemClock.elapsedRealtime()
            val ours = Math.round((now - startedAt) / 60000.0)
            if (Math.abs(ours - mins) >= 1) startedAt = now - mins * 60000
        }

        // Chỉ khi script báo tổng vàng (không có `earned`): cộng phần TĂNG THÊM
        val g = gold
        if (earned == null && g != null) {
            val prev = lastGold
            if (prev != null && g > prev) derived += g - prev
            lastGold = g
        }
    }

    private fun toNum(v: Any): Long? = when (v) {
        is Number -> v.toLong()
        is String -> v.trim().replace(Regex("[.,\\s]"), "").toLongOrNull()
        else -> null
    }
}
