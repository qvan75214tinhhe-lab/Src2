package com.example.scriptweb

import android.annotation.SuppressLint
import android.app.Dialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.InsetDrawable
import android.os.BatteryManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.Window
import android.view.WindowManager
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.webkit.JavaScriptReplyProxy
import androidx.webkit.ScriptHandler
import androidx.webkit.WebMessageCompat
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature

/** ScrollView có chiều cao tối đa, để bảng tiện ích không bao giờ tràn màn hình. */
private class MaxHeightScrollView(ctx: Context, private val maxH: Int) : ScrollView(ctx) {
    override fun onMeasure(w: Int, h: Int) =
        super.onMeasure(w, MeasureSpec.makeMeasureSpec(maxH, MeasureSpec.AT_MOST))
}

class MainActivity : AppCompatActivity() {
    private val START_URL = "https://pokesurvivor.com/"
    // Chặn đoạn kiểm tra cập nhật dành cho bản Chrome extension (script tự bỏ qua nếu có GM_info)
    private val PRELUDE = "window.GM_info = window.GM_info || {};\n"

    private lateinit var web: WebView
    private lateinit var store: ScriptStore
    private val handlers = mutableListOf<ScriptHandler>()

    // ---- Chống nóng máy + chế độ ngủ (không đụng tới menu) ----
    private val ui = Handler(Looper.getMainLooper())
    private val proxies = ArrayDeque<JavaScriptReplyProxy>()
    private val engine by lazy { assets.open("ttv_engine.js").bufferedReader().use { it.readText() } }
    private lateinit var root: FrameLayout
    private lateinit var sleepView: SleepView
    private lateinit var fab: ImageView
    private var sleeping = false
    private var thermal = 0            // 0 mát, 1 ấm, 2 nóng (có độ trễ để không chớp qua lại)
    private var tempC = 0f
    private var battPct = -1
    private var lastPushed = ""
    private var ticks = 0

    // ---- Bảng màu (tự đổi theo chế độ sáng/tối) ----
    private val night get() =
        (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    private val accent = 0xFF00B041.toInt()
    private val danger = 0xFFE53935.toInt()
    private val cSurface get() = if (night) 0xFF1F2421.toInt() else 0xFFFFFFFF.toInt()
    private val cCard get() = if (night) 0xFF2B312D.toInt() else 0xFFF1F5F2.toInt()
    private val cText get() = if (night) 0xFFF2F5F3.toInt() else 0xFF18201B.toInt()
    private val cMuted get() = if (night) 0xFF9AA59E.toInt() else 0xFF66726B.toInt()
    private val cDangerBg get() = if (night) 0xFF3D2625.toInt() else 0xFFFDECEA.toInt()

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri ?: return@registerForActivityResult
        val code = contentResolver.openInputStream(uri)?.bufferedReader()?.readText().orEmpty()
        if (code.isBlank()) { toast("File rỗng"); return@registerForActivityResult }
        store.add(code); applyScripts(); web.reload(); toast("Đã thêm tiện ích")
    }

    @SuppressLint("SetJavaScriptEnabled", "ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)   // không tắt màn hình khi dùng app
        store = ScriptStore(this).also { it.removeLegacyDefault() }

        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            webViewClient = object : WebViewClient() {
                override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                    proxies.clear()   // frame cũ hết hiệu lực, frame mới tự đăng ký lại
                    super.onPageStarted(view, url, favicon)
                }
            }
            webChromeClient = WebChromeClient()
        }
        // Cầu nối: engine gửi số liệu đọc từ bảng #psbot của script về để hiện lên màn hình ngủ
        if (WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)) {
            WebViewCompat.addWebMessageListener(web, "TTV", setOf("*"),
                WebViewCompat.WebMessageListener { _, message, _, _, reply -> onBridge(message, reply) })
        }

        root = FrameLayout(this)
        root.addView(web, ViewGroup.LayoutParams(-1, -1))

        // Nút logo (nằm ngoài trang web), kéo thả được, bấm để mở bảng tiện ích
        val size = dp(52)
        fab = roundedImage(R.drawable.logo, size / 2).apply {
            elevation = dp(6).toFloat(); alpha = 0.92f
            contentDescription = "Tiện ích"
        }
        root.addView(fab, FrameLayout.LayoutParams(size, size, Gravity.BOTTOM or Gravity.END).apply {
            setMargins(0, 0, dp(12), dp(80))
        })
        var dx = 0f; var dy = 0f; var moved = false; var fired = false
        val longPress = Runnable {
            if (!moved) { fired = true; fab.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS); enterSleep() }
        }
        fab.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { dx = v.x - e.rawX; dy = v.y - e.rawY; moved = false; fired = false; ui.postDelayed(longPress, 700) }
                MotionEvent.ACTION_MOVE -> {
                    val nx = e.rawX + dx; val ny = e.rawY + dy
                    if (Math.abs(nx - v.x) + Math.abs(ny - v.y) > 6) { moved = true; ui.removeCallbacks(longPress) }
                    v.x = nx.coerceIn(0f, (root.width - v.width).toFloat())
                    v.y = ny.coerceIn(0f, (root.height - v.height).toFloat())
                }
                MotionEvent.ACTION_UP -> { ui.removeCallbacks(longPress); if (!moved && !fired) showPanel() }
                MotionEvent.ACTION_CANCEL -> ui.removeCallbacks(longPress)
            }
            true
        }

        sleepView = SleepView(this) { exitSleep() }.apply { visibility = View.GONE }
        root.addView(sleepView, ViewGroup.LayoutParams(-1, -1))
        setContentView(root)

        ContextCompat.registerReceiver(this, battery, IntentFilter(Intent.ACTION_BATTERY_CHANGED),
            ContextCompat.RECEIVER_NOT_EXPORTED)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { if (sleeping) exitSleep() else if (web.canGoBack()) web.goBack() else finish() }
        })

        applyScripts()
        web.loadUrl(START_URL)
    }

    /** Gỡ hết script cũ rồi đăng ký lại các script đang BẬT, chạy ở document-start. */
    private fun applyScripts() {
        handlers.forEach { it.remove() }; handlers.clear()
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            toast("WebView quá cũ, hãy cập nhật Android System WebView"); return
        }
        handlers += WebViewCompat.addDocumentStartJavaScript(web, cfgPrefix() + engine, setOf("*"))
        store.list().filter { it.enabled }.forEach { s ->
            handlers += WebViewCompat.addDocumentStartJavaScript(web, PRELUDE + s.code, s.originRules())
        }
    }

    // ================= Chống nóng máy =================

    /** Mức giảm đồ hoạ (preset của bản Lite): đang ngủ hoặc máy nóng -> max; ấm -> strong; mát -> light. */
    private fun preset() = when {
        sleeping || thermal >= 2 -> "max"
        thermal == 1 -> "strong"
        else -> "light"
    }
    private fun scanMs() = if (sleeping) 3000 else 8000
    private fun cfgJson() = """{"preset":"${preset()}","scanMs":${scanMs()}}"""
    private fun cfgPrefix() = "window.__ttvCfg=" + cfgJson() + ";\n"

    /** Đẩy cấu hình mới xuống mọi frame của trang, không cần tải lại. */
    private fun pushConfig() {
        val j = cfgJson()
        if (j == lastPushed) return
        lastPushed = j
        proxies.forEach { try { it.postMessage(j) } catch (_: Throwable) {} }
    }

    private val battery = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            tempC = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10f
            val lvl = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100).coerceAtLeast(1)
            battPct = if (lvl >= 0) lvl * 100 / scale else -1
            // Có độ trễ: lên mức ở 38°C / 42°C, chỉ xuống lại khi dưới 36°C / 40°C
            val up = if (tempC >= 42f) 2 else if (tempC >= 38f) 1 else 0
            val down = if (tempC >= 40f) 2 else if (tempC >= 36f) 1 else 0
            thermal = if (up > thermal) up else if (down < thermal) down else thermal
            pushConfig()
        }
    }

    private fun onBridge(message: WebMessageCompat, reply: JavaScriptReplyProxy) {
        val data = message.data ?: return
        if (data.length > 4000) return
        if (data.startsWith("{\"hello\"")) {
            if (proxies.none { it === reply }) {
                proxies.addLast(reply)
                while (proxies.size > 24) proxies.removeFirst()
            }
            try { reply.postMessage(cfgJson()) } catch (_: Throwable) {}
            return
        }
        FarmState.ingest(data)
    }

    // ================= Chế độ ngủ =================

    private val tick = object : Runnable {
        override fun run() {
            if (!sleeping) return
            sleepView.refresh(statusLine())
            if (++ticks % 60 == 0) sleepView.drift()
            ui.postDelayed(this, 1000)
        }
    }

    private fun enterSleep() {
        if (sleeping) return
        sleeping = true; ticks = 0
        sleepView.visibility = View.VISIBLE
        sleepView.refresh(statusLine()); sleepView.drift()
        setBrightness(0.01f)
        WindowCompat.getInsetsController(window, root).apply {
            systemBarsBehavior = androidx.core.view.WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            hide(WindowInsetsCompat.Type.systemBars())
        }
        pushConfig()
        ui.removeCallbacks(tick); ui.postDelayed(tick, 1000)
        toast("Chạm 2 lần để thức dậy")
    }

    private fun exitSleep() {
        if (!sleeping) return
        sleeping = false
        ui.removeCallbacks(tick)
        sleepView.visibility = View.GONE
        setBrightness(WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE)
        WindowCompat.getInsetsController(window, root).show(WindowInsetsCompat.Type.systemBars())
        pushConfig()
    }

    private fun setBrightness(v: Float) {
        val lp = window.attributes; lp.screenBrightness = v; window.attributes = lp
    }

    private fun statusLine(): String {
        val level = when (preset()) { "light" -> "Nhẹ"; "strong" -> "Vừa"; else -> "Tối đa" }
        val parts = mutableListOf<String>()
        if (battPct >= 0) parts += "🔋 $battPct%"
        if (tempC > 0f) parts += "🌡 ${"%.1f".format(tempC)}°C"
        parts += "⚡ Giảm đồ họa: $level"
        return parts.joinToString("    ")
    }

    override fun onStart() { super.onStart(); if (sleeping) { ui.removeCallbacks(tick); ui.post(tick) } }
    override fun onStop() { ui.removeCallbacks(tick); super.onStop() }
    override fun onDestroy() {
        ui.removeCallbacksAndMessages(null)
        try { unregisterReceiver(battery) } catch (_: Exception) {}
        super.onDestroy()
    }

    // ================= Giao diện bảng tiện ích =================

    private fun showPanel() {
        var changed = false
        lateinit var dialog: Dialog

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(20))
        }

        // Đầu bảng: logo + tên app
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(roundedImage(R.drawable.logo, 12), LinearLayout.LayoutParams(dp(44), dp(44)))
        header.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, 0, 0)
            addView(label("TungTomVND", 18f, cText, bold = true))
            addView(label("Quản lý tiện ích", 13f, cMuted))
        })
        content.addView(header)

        // Danh sách tiện ích
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scripts = store.list()
        if (scripts.isEmpty()) {
            list.addView(LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                background = rounded(cCard, 16)
                setPadding(dp(20), dp(28), dp(20), dp(28))
                addView(label("Chưa có tiện ích nào", 15f, cText, bold = true).apply { gravity = Gravity.CENTER })
                addView(label("Bấm “Thêm tiện ích” rồi chọn file .js để bắt đầu.", 13f, cMuted).apply {
                    gravity = Gravity.CENTER; setPadding(0, dp(6), 0, 0)
                })
            })
        }
        scripts.forEach { s ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = rounded(cCard, 16)
                setPadding(dp(16), dp(12), dp(12), dp(12))
            }
            val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            info.addView(label(s.name, 15f, cText, bold = true).apply { maxLines = 2; ellipsize = TextUtils.TruncateAt.END })
            if (s.description.isNotBlank())
                info.addView(label(s.description, 12f, cMuted).apply {
                    maxLines = 2; ellipsize = TextUtils.TruncateAt.END; setPadding(0, dp(2), 0, 0)
                })
            row.addView(info, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

            row.addView(SwitchCompat(this).apply {
                isChecked = s.enabled
                thumbTintList = ColorStateList(
                    arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                    intArrayOf(Color.WHITE, if (night) 0xFFB8C0BB.toInt() else 0xFFFFFFFF.toInt()))
                trackTintList = ColorStateList(
                    arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                    intArrayOf(accent, if (night) 0xFF4A524D.toInt() else 0xFFC9D1CC.toInt()))
                setOnCheckedChangeListener { _, on -> store.setEnabled(s.id, on); changed = true }
            }, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(8) })

            row.addView(button("Xóa", danger, cDangerBg, 13f, 14, 8) {
                confirmDelete(s) { store.delete(s.id); changed = true; dialog.dismiss() }
            }, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(10) })

            list.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        }
        val maxH = (resources.displayMetrics.heightPixels * 0.5f).toInt()
        content.addView(MaxHeightScrollView(this, maxH).apply {
            isVerticalScrollBarEnabled = false
            addView(list)
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) })

        // Nút hành động
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(button("Đóng", cText, cCard, 15f, 16, 14) { dialog.dismiss() },
            LinearLayout.LayoutParams(0, -2, 1f))
        actions.addView(button("Thêm tiện ích", Color.WHITE, accent, 15f, 16, 14) {
            picker.launch(arrayOf("*/*"))
            dialog.dismiss()
        }, LinearLayout.LayoutParams(0, -2, 1.5f).apply { leftMargin = dp(10) })
        content.addView(actions, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })

        dialog = sheet(content)
        dialog.setOnDismissListener { if (changed) { applyScripts(); web.reload() } }
        dialog.show()
    }

    private fun confirmDelete(s: UserScript, onConfirm: () -> Unit) {
        lateinit var d: Dialog
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(20))
            addView(label("Xóa tiện ích?", 18f, cText, bold = true))
            addView(label("“${s.name}” sẽ bị xóa khỏi app.", 14f, cMuted).apply { setPadding(0, dp(6), 0, dp(18)) })
            addView(LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                addView(button("Hủy", cText, cCard, 15f, 16, 14) { d.dismiss() }, LinearLayout.LayoutParams(0, -2, 1f))
                addView(button("Xóa", Color.WHITE, danger, 15f, 16, 14) { d.dismiss(); onConfirm() },
                    LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(10) })
            })
        }
        d = sheet(content)
        d.show()
    }

    // ================= Công cụ dựng giao diện =================

    /** Hộp thoại dạng bảng nổi từ dưới lên, bo tròn cả bốn góc. */
    private fun sheet(content: View): Dialog {
        content.background = rounded(cSurface, 28)
        return Dialog(this).apply {
            requestWindowFeature(Window.FEATURE_NO_TITLE)
            setContentView(content)
            window?.apply {
                setBackgroundDrawable(InsetDrawable(ColorDrawable(Color.TRANSPARENT), dp(12)))
                setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                setGravity(Gravity.BOTTOM)
            }
        }
    }

    private fun rounded(color: Int, radiusDp: Int) = GradientDrawable().apply {
        cornerRadius = dp(radiusDp).toFloat(); setColor(color)
    }

    private fun label(text: String, sizeSp: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        this.text = text; textSize = sizeSp; setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun button(text: String, fg: Int, bg: Int, sizeSp: Float, padH: Int, padV: Int, onClick: () -> Unit) =
        TextView(this).apply {
            this.text = text; textSize = sizeSp; setTextColor(fg); typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = rounded(bg, 24)
            setPadding(dp(padH), dp(padV), dp(padH), dp(padV))
            setOnClickListener { onClick() }
        }

    /** Ảnh bo góc (radius = nửa cạnh thì thành hình tròn). */
    private fun roundedImage(res: Int, radiusDp: Int) = ImageView(this).apply {
        setImageResource(res); scaleType = ImageView.ScaleType.CENTER_CROP
        clipToOutline = true
        outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: Outline) {
                o.setRoundRect(0, 0, v.width, v.height, dp(radiusDp).toFloat())
            }
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
