package com.example.scriptweb

import android.content.Context
import java.io.File
import java.util.UUID

data class UserScript(
    val id: String,
    val name: String,
    val description: String,
    val code: String,
    val enabled: Boolean
) {
    /** Chuyển các dòng @match thành origin rule cho addDocumentStartJavaScript (không có path). */
    fun originRules(): Set<String> {
        val rules = linkedSetOf<String>()
        Regex("//\\s*@match\\s+(\\S+)").findAll(code).forEach { m ->
            val v = m.groupValues[1]
            val r = Regex("^(\\*|https?)://([^/]+)").find(v)
            if (v == "<all_urls>" || r == null) { rules.add("*"); return@forEach }
            val (scheme, host) = r.destructured
            if (scheme == "*") { rules.add("http://$host"); rules.add("https://$host") } else rules.add("$scheme://$host")
        }
        return if (rules.isEmpty()) setOf("*") else rules
    }
}

class ScriptStore(private val ctx: Context) {
    private val dir = File(ctx.filesDir, "scripts").apply { mkdirs() }
    private val prefs = ctx.getSharedPreferences("scripts", Context.MODE_PRIVATE)

    /** App không còn tiện ích có sẵn. Bản cũ đã cài sẽ được dọn script mặc định một lần duy nhất. */
    fun removeLegacyDefault() {
        if (prefs.getBoolean("legacy_default_removed", false)) return
        list().filter { it.code.contains("pokesurvivor-autofarm") }.forEach { delete(it.id) }
        prefs.edit().putBoolean("legacy_default_removed", true).apply()
    }

    fun list(): List<UserScript> =
        dir.listFiles { f -> f.extension == "js" }.orEmpty().sortedBy { it.name }.map { f ->
            val code = f.readText()
            val id = f.nameWithoutExtension
            UserScript(
                id,
                Regex("//\\s*@name\\s+(.+)").find(code)?.groupValues?.get(1)?.trim() ?: id,
                Regex("//\\s*@description\\s+(.+)").find(code)?.groupValues?.get(1)?.trim().orEmpty(),
                code,
                prefs.getBoolean(id, true)
            )
        }

    fun setEnabled(id: String, on: Boolean) = prefs.edit().putBoolean(id, on).apply()

    fun add(code: String) {
        val id = UUID.randomUUID().toString().take(8)
        File(dir, "$id.js").writeText(code)
    }

    fun delete(id: String) {
        File(dir, "$id.js").delete()
        prefs.edit().remove(id).apply()
    }
}
